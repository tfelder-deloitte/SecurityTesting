declare module 'danger-plugin-jest' {
  declare module.exports: any;
}
