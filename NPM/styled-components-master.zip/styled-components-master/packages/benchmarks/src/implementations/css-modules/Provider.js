import View from './View';
export default View;
