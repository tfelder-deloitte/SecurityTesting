**The documentation has been moved to [styled-components.com](https://www.styled-components.com/docs/advanced#tagged-template-literals), please update your bookmarks!**
